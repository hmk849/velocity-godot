extends Node
## Autoload: AuthService
## 认证接口层。当前只有「本地游客」provider 是真实可用的。
## Apple / Google / 邮箱 需要认证后端（规划 Phase 5，见 ARCHITECTURE.md），
## 这里明确返回失败，不假装登录成功。
##
## login() 统一为异步接口，后续接网络 provider 时 UI 代码不用改。

enum Provider { GUEST, APPLE, GOOGLE, EMAIL }

const SAVE_PATH := "user://account.cfg"

var logged_in := false
var profile: Dictionary = {"id": "", "nickname": "OPERATOR", "level": 1, "provider": "none"}


## 返回 { "ok": bool, "error": String, "profile": Dictionary }
func login(provider: Provider) -> Dictionary:
    await get_tree().process_frame
    match provider:
        Provider.GUEST:
            return _login_guest()
        _:
            return {
                "ok": false,
                "error": "该登录方式需要认证后端，当前版本仅支持游客登录。",
                "profile": {},
            }


func _login_guest() -> Dictionary:
    var cfg := ConfigFile.new()
    cfg.load(SAVE_PATH)
    var id: String = cfg.get_value("guest", "id", "")
    var nick: String = cfg.get_value("guest", "nickname", "")
    if id.is_empty():
        id = Crypto.new().generate_random_bytes(8).hex_encode()
        nick = "OPERATOR_%s" % id.substr(0, 4).to_upper()
        cfg.set_value("guest", "id", id)
        cfg.set_value("guest", "nickname", nick)
        cfg.save(SAVE_PATH)
    profile = {"id": id, "nickname": nick, "level": 1, "provider": "guest"}
    logged_in = true
    return {"ok": true, "error": "", "profile": profile}


func logout() -> void:
    logged_in = false
    profile = {"id": "", "nickname": "OPERATOR", "level": 1, "provider": "none"}
