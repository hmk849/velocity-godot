class_name TargetDummy
extends Node3D
## 训练靶: 躯干 + 头两个命中区。击杀后隐藏，几秒后重生。

@export var max_health := 100.0
@export var respawn_time := 2.0

var health := 100.0
var _alive := true
var _parts: Array[Dictionary] = []   # { "mat": StandardMaterial3D, "base": Color, "zone": HitZone }


func _ready() -> void:
    health = max_health
    var torso := BoxMesh.new()
    torso.size = Vector3(0.6, 1.0, 0.3)
    _add_part(torso, BoxShape3D.new(), Vector3(0, 1.0, 0), false, UITheme.WARN, Vector3(0.6, 1.0, 0.3))
    var head := SphereMesh.new()
    head.radius = 0.16
    head.height = 0.32
    var hs := SphereShape3D.new()
    hs.radius = 0.16
    _add_part(head, hs, Vector3(0, 1.72, 0), true, Color("ffb070"), Vector3.ZERO)


func _add_part(mesh: Mesh, shape: Shape3D, pos: Vector3, is_head: bool, color: Color, box_size: Vector3) -> void:
    var zone := HitZone.new()
    zone.is_head = is_head
    zone.target = self
    zone.position = pos
    if shape is BoxShape3D:
        (shape as BoxShape3D).size = box_size
    var cs := CollisionShape3D.new()
    cs.shape = shape
    zone.add_child(cs)
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mi.material_override = mat
    zone.add_child(mi)
    add_child(zone)
    _parts.append({"mat": mat, "base": color, "zone": zone})


## 返回是否被这次伤害击杀
func take_damage(amount: float) -> bool:
    if not _alive:
        return false
    health -= amount
    _flash()
    if health <= 0.0:
        _die()
        return true
    return false


func _flash() -> void:
    for p in _parts:
        var mat: StandardMaterial3D = p.mat
        mat.albedo_color = Color.WHITE
        var tw := create_tween()
        tw.tween_property(mat, "albedo_color", p.base, 0.12)


func _die() -> void:
    _alive = false
    visible = false
    for p in _parts:
        (p.zone as HitZone).collision_layer = 0
    get_tree().create_timer(respawn_time).timeout.connect(_respawn)


func _respawn() -> void:
    health = max_health
    _alive = true
    visible = true
    for p in _parts:
        (p.zone as HitZone).collision_layer = 1
