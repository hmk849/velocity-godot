extends Node3D
## 训练场（临时测试地图，代码生成几何体）。
## 用途: 验证移动手感、射击、TTK、触屏操作。正式地图（NEON DISTRICT 等）
## 将用编辑器制作 .tscn 并替换本场景。

const WEAPON_PATHS := [
    "res://data/weapons/vx1_rifle.tres",
    "res://data/weapons/vp9_smg.tres",
]

var _touch: TouchControls
var _materials: Dictionary = {}
var _grid_tex: ImageTexture


func _ready() -> void:
    _build_environment()
    _build_arena()
    _build_targets()
    _build_ui()
    _spawn_player()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:    # Android 返回键
        _back_to_lobby()


func _back_to_lobby() -> void:
    SceneRouter.goto("res://ui/lobby/lobby.tscn")


# ---------- 环境 / 光照（移动端预算: 1 盏带阴影的平行光，无天空盒）----------
func _build_environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("1b232b")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("8895a3")
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -30, 0)
    sun.shadow_enabled = true
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
    sun.directional_shadow_max_distance = 60.0
    add_child(sun)


# ---------- 几何体 ----------
func _grid_texture() -> ImageTexture:
    if _grid_tex == null:
        var img := Image.create(64, 64, false, Image.FORMAT_RGB8)
        img.fill(Color("ffffff"))
        for i in 64:
            for k in 2:
                img.set_pixel(i, k, Color("b0b8c0"))
                img.set_pixel(k, i, Color("b0b8c0"))
        img.generate_mipmaps()
        _grid_tex = ImageTexture.create_from_image(img)
    return _grid_tex


func _material(color: Color) -> StandardMaterial3D:
    var key := color.to_html()
    if not _materials.has(key):
        var m := StandardMaterial3D.new()
        m.albedo_color = color
        m.albedo_texture = _grid_texture()
        m.uv1_triplanar = true
        m.uv1_world_triplanar = true
        m.uv1_scale = Vector3(0.25, 0.25, 0.25)
        m.roughness = 0.9
        _materials[key] = m
    return _materials[key]


func _add_box(pos: Vector3, size: Vector3, color: Color, rot_deg := Vector3.ZERO) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.rotation_degrees = rot_deg
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    body.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _material(color)
    body.add_child(mi)
    add_child(body)


func _build_arena() -> void:
    var floor_c := Color("5a6672")
    var wall_c := Color("7a8794")
    var prop_c := Color("a4b0bc")
    _add_box(Vector3(0, -0.5, 0), Vector3(120, 1, 120), floor_c)
    # 围墙（8 米高，留给后续蹬墙跑测试）
    _add_box(Vector3(0, 4, -60), Vector3(120, 8, 1), wall_c)
    _add_box(Vector3(0, 4, 60), Vector3(120, 8, 1), wall_c)
    _add_box(Vector3(-60, 4, 0), Vector3(1, 8, 120), wall_c)
    _add_box(Vector3(60, 4, 0), Vector3(1, 8, 120), wall_c)
    # 滑铲坡道
    _add_box(Vector3(-14, 1.2, 10), Vector3(6, 0.5, 16), prop_c, Vector3(-15, 0, 0))
    # 台阶 / 平台（跳跃、二段跳测试）
    _add_box(Vector3(14, 0.5, 14), Vector3(6, 1, 6), prop_c)
    _add_box(Vector3(14, 1.5, 22), Vector3(6, 3, 6), prop_c)
    _add_box(Vector3(14, 2.5, 30), Vector3(6, 5, 6), prop_c)
    # 掩体
    for i in 5:
        _add_box(Vector3(-8 + i * 4.0, 0.75, -6.0), Vector3(2.0, 1.5, 0.6), prop_c)
    # 长跑道（冲刺 → 滑铲 → 滑铲跳）
    _add_box(Vector3(30, 3, -30), Vector3(0.6, 6, 40), wall_c)
    _add_box(Vector3(36, 3, -30), Vector3(0.6, 6, 40), wall_c)


func _build_targets() -> void:
    for z in [-14.0, -24.0, -36.0, -50.0]:
        for x in [-4.0, 4.0]:
            var t := TargetDummy.new()
            t.position = Vector3(x, 0, z)
            add_child(t)


# ---------- UI / 玩家 ----------
func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    add_child(layer)
    if Game.is_mobile:
        _touch = TouchControls.new()
        layer.add_child(_touch)
    var hud := HUD.new()
    layer.add_child(hud)
    hud.back_requested.connect(_back_to_lobby)


func _spawn_player() -> void:
    var p := Player.new()
    p.position = Vector3(0, 0.2, 8)
    p.touch = _touch
    for path in WEAPON_PATHS:
        p.loadout.append(load(path) as WeaponData)
    add_child(p)
