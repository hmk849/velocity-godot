class_name Player
extends CharacterBody3D
## 第一人称角色。状态: GROUND / AIR / SLIDE。
## 已实现: 走、冲刺、跳、二段跳、滑铲、滑铲跳、空中保持动量与转向、速度 FOV。
## 未实现（Phase 2 继续）: 蹬墙跑、墙跳、翻越、攀爬、钩爪、滑索、第三人称动画。
## 注意: 本地单机逻辑。联网时需改成「输入 → 预测 → 服务器校正」（Phase 5）。

enum State { GROUND, AIR, SLIDE }

const MOUSE_RAD := 0.0022
const TOUCH_RAD := 0.0035
const MAX_PITCH := 1.5359   # 88°

@export_group("Movement")
@export var walk_speed := 6.0
@export var sprint_speed := 9.5
@export var ground_accel := 70.0
@export var ground_decel := 50.0
@export var overspeed_decel := 10.0    # 超过目标速度时的缓慢衰减（保留动量）
@export var air_accel := 14.0
@export var gravity := 24.0
@export var jump_velocity := 7.5
@export var max_air_jumps := 1
@export var slide_boost := 3.0
@export var slide_max_speed := 13.0
@export var slide_decel := 6.0
@export var slide_steer := 2.0
@export var slide_min_speed := 4.0
@export var slide_max_time := 1.1
@export var stand_eye := 1.65
@export var slide_eye := 0.9

var state := State.GROUND
var touch: TouchControls = null        # 手机上由地图注入
var loadout: Array[WeaponData] = []
var weapon: Weapon
var head: Node3D
var camera: Camera3D

var yaw := 0.0
var pitch := 0.0

var _move_input := Vector2.ZERO        # x=右, y=前
var _wish_dir := Vector3.ZERO
var _wish_mag := 0.0
var _sprinting := false
var _jump_pressed := false
var _slide_pressed := false
var _slide_held := false
var _slide_t := 0.0
var _slide_cd := 0.0
var _air_jumps := 0
var _slot := 0
var _spawn_pos := Vector3.ZERO
var _base_fov := 90.0


func _ready() -> void:
    _spawn_pos = position
    _base_fov = Settings.fov

    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)

    head = Node3D.new()
    head.position.y = stand_eye
    add_child(head)
    camera = Camera3D.new()
    camera.fov = _base_fov
    camera.near = 0.05
    head.add_child(camera)

    weapon = Weapon.new()
    weapon.player = self
    weapon.camera = camera
    camera.add_child(weapon)
    if loadout.size() > 0:
        weapon.equip(loadout[0])

    if not Game.is_mobile:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _exit_tree() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# ---------- 输入 ----------
func _unhandled_input(event: InputEvent) -> void:
    if Game.is_mobile:
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        var k := MOUSE_RAD * Settings.look_sens
        add_look(-event.relative.x * k, -event.relative.y * k)
    elif event.is_action_pressed("ui_cancel"):
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif event is InputEventMouseButton and event.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func add_look(d_yaw: float, d_pitch: float) -> void:
    yaw += d_yaw
    pitch = clampf(pitch + d_pitch, -MAX_PITCH, MAX_PITCH)


func is_fire_held() -> bool:
    return Input.is_action_pressed("fire") or (touch != null and touch.fire_held)


func consume_reload() -> bool:
    var r := Input.is_action_just_pressed("reload")
    if touch != null and touch.consume("reload"):
        r = true
    return r


func speed_ratio() -> float:
    return clampf(_horizontal_speed() / sprint_speed, 0.0, 1.0)


func _horizontal_speed() -> float:
    return Vector2(velocity.x, velocity.z).length()


func _poll_input() -> void:
    var tv := touch.move_vector if touch != null else Vector2.ZERO
    _move_input = Input.get_vector("move_left", "move_right", "move_back", "move_forward") + tv
    if _move_input.length() > 1.0:
        _move_input = _move_input.normalized()

    var dir := global_transform.basis * Vector3(_move_input.x, 0.0, -_move_input.y)
    dir.y = 0.0
    _wish_dir = dir.normalized()
    _wish_mag = _move_input.length()

    var auto_sprint := Settings.auto_sprint and touch != null \
        and tv.length() > 0.92 and tv.y > 0.3
    _sprinting = Input.is_action_pressed("sprint") or auto_sprint

    _jump_pressed = Input.is_action_just_pressed("jump")
    _slide_pressed = Input.is_action_just_pressed("slide")
    _slide_held = Input.is_action_pressed("slide")
    if touch != null:
        _jump_pressed = _jump_pressed or touch.consume("jump")
        _slide_pressed = _slide_pressed or touch.consume("slide")

    if Input.is_action_just_pressed("swap") or (touch != null and touch.consume("swap")):
        _cycle_weapon()


func _cycle_weapon() -> void:
    if loadout.size() < 2:
        return
    _slot = (_slot + 1) % loadout.size()
    weapon.equip(loadout[_slot])


# ---------- 帧更新 ----------
func _process(delta: float) -> void:
    if touch != null:
        var d := touch.consume_look()
        if d != Vector2.ZERO:
            var k := TOUCH_RAD * Settings.look_sens
            add_look(-d.x * k, -d.y * k)
    rotation.y = yaw
    head.rotation.x = pitch

    var eye := slide_eye if state == State.SLIDE else stand_eye
    head.position.y = lerpf(head.position.y, eye, 1.0 - exp(-14.0 * delta))
    var fov_kick := clampf((_horizontal_speed() - walk_speed) * 1.2, 0.0, 8.0)
    camera.fov = lerpf(camera.fov, _base_fov + fov_kick, 1.0 - exp(-8.0 * delta))


func _physics_process(delta: float) -> void:
    _poll_input()
    _slide_cd = maxf(_slide_cd - delta, 0.0)
    if not is_on_floor():
        velocity.y -= gravity * delta

    match state:
        State.GROUND:
            _tick_ground(delta)
        State.AIR:
            _tick_air(delta)
        State.SLIDE:
            _tick_slide(delta)

    move_and_slide()

    if global_position.y < -30.0:
        global_position = _spawn_pos
        velocity = Vector3.ZERO
        state = State.AIR


func _speed_mult() -> float:
    if weapon != null and weapon.data != null:
        return weapon.data.move_speed_mult
    return 1.0


func _tick_ground(delta: float) -> void:
    if not is_on_floor():
        state = State.AIR
        return
    _air_jumps = max_air_jumps
    if _jump_pressed:
        velocity.y = jump_velocity
        state = State.AIR
        return
    if _slide_pressed and _slide_cd <= 0.0 and _horizontal_speed() >= walk_speed * 1.1:
        _start_slide()
        return

    var top := sprint_speed if _sprinting else walk_speed
    var target := _wish_dir * top * _wish_mag * _speed_mult()
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var rate := ground_accel
    if h.length() > target.length() + 0.01:
        # 无输入 → 快速停下；有输入但超速（例如滑铲落地）→ 缓慢衰减，保留动量
        rate = ground_decel if target.length() < 0.1 else overspeed_decel
    h = h.move_toward(target, rate * delta)
    velocity.x = h.x
    velocity.z = h.z


func _tick_air(delta: float) -> void:
    if is_on_floor() and velocity.y <= 0.0:
        state = State.GROUND
        return
    if _jump_pressed and _air_jumps > 0:
        _air_jumps -= 1
        velocity.y = jump_velocity * 0.9
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var cap := maxf(h.length(), walk_speed)    # 空中可转向，但不会凭空加速
    h += _wish_dir * _wish_mag * air_accel * delta
    if h.length() > cap:
        h = h.normalized() * cap
    velocity.x = h.x
    velocity.z = h.z


func _start_slide() -> void:
    state = State.SLIDE
    _slide_t = 0.0
    var h := Vector3(velocity.x, 0.0, velocity.z)
    var spd := minf(maxf(h.length(), sprint_speed) + slide_boost, slide_max_speed)
    var dir := h.normalized()
    velocity.x = dir.x * spd
    velocity.z = dir.z * spd


func _tick_slide(delta: float) -> void:
    _slide_t += delta
    if not is_on_floor():
        state = State.AIR           # 滑出平台边缘，保留动量
        return
    if _jump_pressed:
        velocity.y = jump_velocity  # 滑铲跳: 水平速度原样保留
        state = State.AIR
        _slide_cd = 0.3
        return

    var h := Vector3(velocity.x, 0.0, velocity.z)
    var spd := maxf(h.length() - slide_decel * delta, 0.0)
    if h.length() > 0.01:
        var dir := h.normalized()
        if _wish_dir.length() > 0.1:
            dir = dir.slerp(_wish_dir, clampf(slide_steer * delta, 0.0, 1.0)).normalized()
        h = dir * spd
        velocity.x = h.x
        velocity.z = h.z

    var hold_required := not Game.is_mobile
    if spd < slide_min_speed or _slide_t > slide_max_time or (hold_required and not _slide_held):
        state = State.GROUND
        _slide_cd = 0.4
