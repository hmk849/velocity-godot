class_name Weapon
extends Node3D
## 武器运行时（挂在相机下）。Hitscan 射击 + 弹匣/换弹 + 后坐力 + 简易枪模反馈。
## 数据来自 WeaponData。弹道（子弹飞行/穿透）、ADS、配件属 Phase 3。
## 注意: 现在是单机本地判定；联网后命中判定必须搬到服务器（Phase 5）。

var data: WeaponData
var ammo := 0
var player: Player
var camera: Camera3D

var _cooldown := 0.0
var _reload_left := 0.0
var _shot_index := 0
var _since_last := 99.0
var _fire_prev := false
var _ammo_store: Dictionary = {}
var _rng := RandomNumberGenerator.new()

var _vm: MeshInstance3D
var _vm_base := Vector3(0.2, -0.2, -0.6)
var _flash: OmniLight3D
var _impact_mat: StandardMaterial3D
var _vm_tween: Tween


func _ready() -> void:
    _rng.randomize()
    _vm = MeshInstance3D.new()
    _vm.mesh = BoxMesh.new()
    _vm.material_override = StandardMaterial3D.new()
    add_child(_vm)
    _flash = OmniLight3D.new()
    _flash.omni_range = 4.0
    _flash.light_color = Color("ffcc88")
    _flash.light_energy = 0.0
    _vm.add_child(_flash)
    _impact_mat = StandardMaterial3D.new()
    _impact_mat.albedo_color = UITheme.WARN
    _impact_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED


func equip(d: WeaponData) -> void:
    if data != null:
        _ammo_store[data.display_name] = ammo
    data = d
    ammo = _ammo_store.get(d.display_name, d.magazine_size)
    _reload_left = 0.0
    _cooldown = 0.2
    _shot_index = 0
    if _vm_tween:
        _vm_tween.kill()
    var mesh := _vm.mesh as BoxMesh
    mesh.size = d.viewmodel_size
    (_vm.material_override as StandardMaterial3D).albedo_color = d.viewmodel_color
    _vm_base = Vector3(0.2, -0.2, -(0.3 + d.viewmodel_size.z * 0.5))
    _vm.position = _vm_base
    _vm.rotation = Vector3.ZERO
    _flash.position = Vector3(0, 0.02, -d.viewmodel_size.z * 0.5 - 0.1)
    EventBus.weapon_changed.emit(d.display_name, d.theoretical_ttk_ms())
    _emit_ammo()


func _physics_process(delta: float) -> void:
    if data == null or player == null:
        return
    _cooldown = maxf(_cooldown - delta, 0.0)
    _since_last += delta

    var fire := player.is_fire_held()
    var fire_edge := fire and not _fire_prev
    _fire_prev = fire
    var reload_req := player.consume_reload()

    if _reload_left > 0.0:
        _reload_left -= delta
        if _reload_left <= 0.0:
            _reload_left = 0.0
            ammo = data.magazine_size
            _emit_ammo()
        return
    if reload_req:
        start_reload()
        return
    if ammo <= 0:
        start_reload()     # 空仓自动换弹
        return
    if _cooldown > 0.0:
        return
    if (data.automatic and fire) or fire_edge:
        _fire()


func start_reload() -> void:
    if _reload_left > 0.0 or ammo >= data.magazine_size:
        return
    _reload_left = data.reload_time
    _emit_ammo()
    if _vm_tween:
        _vm_tween.kill()
    _vm_tween = create_tween()
    _vm_tween.tween_property(_vm, "rotation:x", -0.7, 0.2)
    _vm_tween.tween_interval(maxf(data.reload_time - 0.4, 0.0))
    _vm_tween.tween_property(_vm, "rotation:x", 0.0, 0.2)


func _fire() -> void:
    ammo -= 1
    _cooldown = 60.0 / data.fire_rate_rpm
    if _since_last > data.recoil_reset_time:
        _shot_index = 0
    _since_last = 0.0

    var spread := data.spread_hip_deg + data.spread_move_deg * player.speed_ratio()
    var dir := _spread_dir(spread)
    var from := camera.global_position
    var q := PhysicsRayQueryParameters3D.create(from, from + dir * data.max_range)
    q.exclude = [player.get_rid()]
    var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(q)
    if not hit.is_empty():
        _apply_hit(hit, from)

    var kick: Vector2 = data.recoil_pattern[_shot_index % data.recoil_pattern.size()]
    player.add_look(deg_to_rad(-kick.x), deg_to_rad(kick.y))
    _shot_index += 1
    _kick_viewmodel()
    _emit_ammo()


func _apply_hit(hit: Dictionary, origin: Vector3) -> void:
    var pos: Vector3 = hit.position
    _spawn_impact(pos)
    var col: Object = hit.collider
    if col is HitZone:
        var zone := col as HitZone
        var dmg := data.damage_at(origin.distance_to(pos))
        if zone.is_head:
            dmg *= data.headshot_mult
        var killed := zone.apply_damage(dmg)
        EventBus.hit_confirmed.emit(zone.is_head, killed)


func _spread_dir(deg: float) -> Vector3:
    var cam_basis := camera.global_transform.basis
    var ang := _rng.randf() * TAU
    var mag := sqrt(_rng.randf()) * deg_to_rad(deg)
    var local := Vector3(cos(ang) * sin(mag), sin(ang) * sin(mag), -cos(mag))
    return (cam_basis * local).normalized()


func _kick_viewmodel() -> void:
    _vm.position = _vm_base + Vector3(0.0, 0.012, 0.06)
    var tw := create_tween()
    tw.tween_property(_vm, "position", _vm_base, 0.09)
    _flash.light_energy = 3.0
    var tw2 := create_tween()
    tw2.tween_property(_flash, "light_energy", 0.0, 0.05)


func _spawn_impact(pos: Vector3) -> void:
    var m := MeshInstance3D.new()
    var s := SphereMesh.new()
    s.radius = 0.05
    s.height = 0.1
    s.radial_segments = 8
    s.rings = 4
    m.mesh = s
    m.material_override = _impact_mat
    get_tree().current_scene.add_child(m)
    m.global_position = pos
    get_tree().create_timer(0.8).timeout.connect(m.queue_free)


func _emit_ammo() -> void:
    EventBus.ammo_changed.emit(ammo, data.magazine_size, _reload_left > 0.0)
