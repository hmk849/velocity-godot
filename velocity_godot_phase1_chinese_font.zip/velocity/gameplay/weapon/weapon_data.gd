class_name WeaponData
extends Resource
## 单把武器的全部参数（数据驱动，一把枪一个 .tres）。
## 加新枪 = 复制一个 .tres 改数值，不用改代码。

@export var display_name := "Unnamed"
@export var automatic := true

@export_group("Damage")
@export var damage := 25.0
@export var headshot_mult := 1.5
@export var fire_rate_rpm := 800.0
@export var max_range := 200.0
@export var falloff_start := 20.0
@export var falloff_end := 60.0
@export_range(0.0, 1.0) var min_damage_mult := 0.6

@export_group("Handling")
@export var magazine_size := 30
@export var reload_time := 2.0
@export var move_speed_mult := 1.0
@export var spread_hip_deg := 0.4
@export var spread_move_deg := 1.2

@export_group("Recoil")
## 每发 (水平°, 垂直°)，按发序循环；停火超过 recoil_reset_time 后从头开始
@export var recoil_pattern: PackedVector2Array = PackedVector2Array([
    Vector2(0.0, 0.55), Vector2(0.05, 0.6), Vector2(-0.08, 0.55), Vector2(0.12, 0.5),
    Vector2(-0.1, 0.45), Vector2(0.15, 0.4), Vector2(-0.12, 0.35), Vector2(0.1, 0.3),
])
@export var recoil_reset_time := 0.35

@export_group("Viewmodel (占位)")
@export var viewmodel_size := Vector3(0.07, 0.11, 0.7)
@export var viewmodel_color := Color("39424c")


func damage_at(distance: float) -> float:
    if distance <= falloff_start:
        return damage
    var t := clampf((distance - falloff_start) / maxf(falloff_end - falloff_start, 0.001), 0.0, 1.0)
    return damage * lerpf(1.0, min_damage_mult, t)


## 理论 TTK（毫秒）: 第一发在 t=0，之后每发间隔 60000/rpm
func theoretical_ttk_ms(target_health := 100.0, headshot := false, distance := 0.0) -> float:
    var per_shot := damage_at(distance) * (headshot_mult if headshot else 1.0)
    var shots := ceili(target_health / per_shot)
    return float(maxi(shots - 1, 0)) * 60000.0 / fire_rate_rpm
