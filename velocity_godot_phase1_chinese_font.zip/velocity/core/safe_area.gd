class_name SafeArea
extends RefCounted
## 刘海/圆角/手势条安全区。返回 Vector4(左, 上, 右, 下)，单位是视口坐标。
## 桌面返回 0。

static func margins(vp: Viewport) -> Vector4:
    if not OS.has_feature("mobile"):
        return Vector4.ZERO
    var win := Vector2(DisplayServer.window_get_size())
    if win.x <= 0.0 or win.y <= 0.0:
        return Vector4.ZERO
    var safe := Rect2(DisplayServer.get_display_safe_area())
    var k := vp.get_visible_rect().size / win
    var l := maxf(safe.position.x, 0.0) * k.x
    var t := maxf(safe.position.y, 0.0) * k.y
    var r := maxf(win.x - (safe.position.x + safe.size.x), 0.0) * k.x
    var b := maxf(win.y - (safe.position.y + safe.size.y), 0.0) * k.y
    return Vector4(l, t, r, b)
