extends Node
## Autoload: SceneRouter
## 场景切换 + 黑场过渡。带加载界面的跳转用 goto_with_loading()。

var _fade: ColorRect
var _busy := false


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    var layer := CanvasLayer.new()
    layer.layer = 100
    add_child(layer)
    _fade = ColorRect.new()
    _fade.color = Color(0, 0, 0, 0)
    _fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(_fade)
    _fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


## 直接切换。packed 非空时切到已加载好的 PackedScene（加载界面用）。
func goto(path: String, packed: PackedScene = null) -> void:
    if _busy:
        return
    _busy = true
    var tw_out := create_tween()
    tw_out.tween_property(_fade, "color:a", 1.0, 0.18)
    await tw_out.finished
    if packed != null:
        get_tree().change_scene_to_packed(packed)
    else:
        get_tree().change_scene_to_file(path)
    await get_tree().process_frame
    await get_tree().process_frame
    var tw_in := create_tween()
    tw_in.tween_property(_fade, "color:a", 0.0, 0.25)
    await tw_in.finished
    _busy = false


func goto_with_loading(path: String, info: Dictionary = {}) -> void:
    Game.pending_load = {"path": path, "info": info}
    goto("res://ui/loading/loading.tscn")
