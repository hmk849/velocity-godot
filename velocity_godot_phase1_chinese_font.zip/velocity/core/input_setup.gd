class_name InputSetup
extends RefCounted
## 运行时注册输入动作。
## 桌面: 键鼠调试用。手机: 触屏由 TouchControls 直接处理。
## 注意: 手机上不绑定鼠标键，否则触摸模拟出的鼠标点击会误触发 fire。

static func register_actions() -> void:
    _key("move_forward", KEY_W)
    _key("move_back", KEY_S)
    _key("move_left", KEY_A)
    _key("move_right", KEY_D)
    _key("jump", KEY_SPACE)
    _key("sprint", KEY_SHIFT)
    _key("slide", KEY_C)
    _key("slide", KEY_CTRL)
    _key("reload", KEY_R)
    _key("swap", KEY_Q)
    _ensure("fire")
    _ensure("ads")
    if not OS.has_feature("mobile"):
        _mouse("fire", MOUSE_BUTTON_LEFT)
        _mouse("ads", MOUSE_BUTTON_RIGHT)


static func _ensure(action: StringName) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)


static func _key(action: StringName, keycode: Key) -> void:
    _ensure(action)
    var ev := InputEventKey.new()
    ev.physical_keycode = keycode
    InputMap.action_add_event(action, ev)


static func _mouse(action: StringName, button: MouseButton) -> void:
    _ensure(action)
    var ev := InputEventMouseButton.new()
    ev.button_index = button
    InputMap.action_add_event(action, ev)
