extends Node
## Autoload: EventBus
## 全局信号总线。规则: gameplay 层只发信号，不引用 ui；ui 订阅信号。

signal ammo_changed(current: int, magazine: int, reloading: bool)
signal weapon_changed(display_name: String, ttk_ms: float)
signal hit_confirmed(is_head: bool, killed: bool)
