extends ScreenBase
## 登录界面。游客登录是真实可用的（本地 ID）；
## Apple/Google/邮箱 走 AuthService，当前返回"需要后端"的错误态。

var _buttons: Array[Button] = []


func _build(root: MarginContainer) -> void:
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 24)
    root.add_child(col)

    var main := HBoxContainer.new()
    main.size_flags_vertical = Control.SIZE_EXPAND_FILL
    main.add_theme_constant_override("separation", 64)
    col.add_child(main)

    # 左: 品牌
    var brand := VBoxContainer.new()
    brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    brand.alignment = BoxContainer.ALIGNMENT_CENTER
    brand.add_child(UITheme.label("PROJECT", 36, UITheme.TEXT_DIM))
    brand.add_child(UITheme.label("VELOCITY", 120, UITheme.TITANIUM))
    brand.add_child(UITheme.label("TACTICAL MOBILITY SHOOTER", 26, UITheme.ICE))
    main.add_child(brand)

    # 右: 登录
    var panel := VBoxContainer.new()
    panel.custom_minimum_size = Vector2(520, 0)
    panel.alignment = BoxContainer.ALIGNMENT_CENTER
    panel.add_theme_constant_override("separation", 18)
    main.add_child(panel)
    _add_login(panel, "游客登录", AuthService.Provider.GUEST, true)
    _add_login(panel, "Apple 登录", AuthService.Provider.APPLE)
    _add_login(panel, "Google 登录", AuthService.Provider.GOOGLE)
    _add_login(panel, "邮箱登录 / 注册", AuthService.Provider.EMAIL)

    # 底部: 状态栏
    var foot := HBoxContainer.new()
    foot.add_theme_constant_override("separation", 40)
    col.add_child(foot)
    foot.add_child(UITheme.label("v%s" % Game.VERSION, 22, UITheme.TEXT_DIM))
    foot.add_child(UITheme.label("服务器: 离线（未配置）", 22, UITheme.WARN))
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    foot.add_child(sp)
    var terms := Button.new()
    terms.text = "用户协议 · 隐私政策"
    terms.flat = true
    terms.pressed.connect(show_toast.bind("正式协议文本尚未提供", true))
    foot.add_child(terms)


func _add_login(parent: Control, text: String, provider: int, primary := false) -> void:
    var b := make_button(text, primary, Vector2(0, 84))
    b.pressed.connect(_try_login.bind(provider))
    parent.add_child(b)
    _buttons.append(b)


func _try_login(provider: int) -> void:
    _set_busy(true)
    var res: Dictionary = await AuthService.login(provider)
    _set_busy(false)
    if res.ok:
        SceneRouter.goto("res://ui/lobby/lobby.tscn")
    else:
        show_toast(res.error, true)


func _set_busy(busy: bool) -> void:
    for b in _buttons:
        b.disabled = busy
