class_name HUD
extends Control
## 对局 HUD: 准星、命中标记、弹药、武器名与理论 TTK、FPS、返回大厅按钮。
## 只订阅 EventBus，不引用 gameplay 类。
## 未实现: 受击方向、击杀播报、伤害数字、血条（Phase 3/4）。

signal back_requested

const HIT_TIME := 0.18

var _ammo: Label
var _weapon: Label
var _fps: Label
var _hit_t := 0.0
var _hit_color := Color.WHITE
var _hit_kill := false


func _ready() -> void:
    theme = Game.ui_theme
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var m := SafeArea.margins(get_viewport())
    var margin := MarginContainer.new()
    margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", int(m.x) + 32)
    margin.add_theme_constant_override("margin_top", int(m.y) + 24)
    margin.add_theme_constant_override("margin_right", int(m.z) + 32)
    margin.add_theme_constant_override("margin_bottom", int(m.w) + 24)
    add_child(margin)

    var col := VBoxContainer.new()
    col.mouse_filter = Control.MOUSE_FILTER_IGNORE
    margin.add_child(col)

    var top := HBoxContainer.new()
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    col.add_child(top)
    _fps = UITheme.label("", 22, UITheme.TEXT_DIM)
    _fps.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(_fps)
    var back := Button.new()
    back.text = "返回大厅"
    back.custom_minimum_size = Vector2(200, 64)
    back.pressed.connect(back_requested.emit)
    top.add_child(back)

    var sp := Control.new()
    sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
    sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(sp)

    var bottom := VBoxContainer.new()
    bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bottom.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_child(bottom)
    _weapon = UITheme.label("", 22, UITheme.TEXT_DIM)
    _weapon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _ammo = UITheme.label("", 52, UITheme.TITANIUM)
    _ammo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    bottom.add_child(_weapon)
    bottom.add_child(_ammo)

    EventBus.ammo_changed.connect(_on_ammo)
    EventBus.weapon_changed.connect(_on_weapon)
    EventBus.hit_confirmed.connect(_on_hit)


func _exit_tree() -> void:
    EventBus.ammo_changed.disconnect(_on_ammo)
    EventBus.weapon_changed.disconnect(_on_weapon)
    EventBus.hit_confirmed.disconnect(_on_hit)


func _process(delta: float) -> void:
    _hit_t = maxf(_hit_t - delta, 0.0)
    _fps.text = "%d FPS" % int(Performance.get_monitor(Performance.TIME_FPS)) if Settings.show_fps else ""
    queue_redraw()


func _on_ammo(current: int, magazine: int, reloading: bool) -> void:
    _ammo.text = "换弹中…" if reloading else "%d / %d" % [current, magazine]


func _on_weapon(display_name: String, ttk_ms: float) -> void:
    _weapon.text = "%s   TTK %d ms" % [display_name, int(ttk_ms)]


func _on_hit(is_head: bool, killed: bool) -> void:
    _hit_t = HIT_TIME
    _hit_kill = killed
    _hit_color = UITheme.WARN if (is_head or killed) else Color.WHITE


func _draw() -> void:
    var c := size * 0.5
    var col := Color(1, 1, 1, 0.9)
    for d: Vector2 in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
        draw_line(c + d * 10.0, c + d * 22.0, col, 2.5, true)
    draw_circle(c, 1.5, col)
    if _hit_t > 0.0:
        var a := _hit_t / HIT_TIME
        var hc := Color(_hit_color, a)
        var r1 := 14.0 + (1.0 - a) * 4.0
        var r2 := r1 + (16.0 if _hit_kill else 9.0)
        for d: Vector2 in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
            var n := d.normalized()
            draw_line(c + n * r1, c + n * r2, hc, 3.0, true)
