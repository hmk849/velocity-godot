extends ScreenBase
## 加载界面。进度来自 ResourceLoader.load_threaded_get_status 的真实进度。
## 最短显示 0.8s，避免小场景一闪而过。多人同步/开局条件属 Phase 5。

const MIN_SHOW_TIME := 0.8
const TIPS := [
    "滑铲途中按跳跃，可以带着速度起跳。",
    "冲刺后立刻滑铲，可获得额外初速。",
    "空中可以微调方向，但不会凭空加速。",
    "爆头伤害为躯干的 1.5 倍。",
]

var _bar: ProgressBar
var _pct: Label
var _target := ""
var _elapsed := 0.0
var _finished := false


func _build(root: MarginContainer) -> void:
    var info: Dictionary = Game.pending_load.get("info", {})
    _target = Game.pending_load.get("path", "")
    var p: Dictionary = AuthService.profile

    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 20)
    root.add_child(col)

    var top := HBoxContainer.new()
    col.add_child(top)
    top.add_child(UITheme.label("%s  Lv.%d" % [p.nickname, p.level], 26, UITheme.TITANIUM))
    var sp := Control.new()
    sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(sp)
    top.add_child(UITheme.label("网络: 本地（离线）", 22, UITheme.TEXT_DIM))

    var mid := HBoxContainer.new()
    mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(mid)
    var left := VBoxContainer.new()
    left.alignment = BoxContainer.ALIGNMENT_END
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    left.add_child(UITheme.label(info.get("map_name", "MAP"), 96, UITheme.TITANIUM))
    left.add_child(UITheme.label(TIPS[randi() % TIPS.size()], 26, UITheme.ICE))
    mid.add_child(left)
    var right := VBoxContainer.new()
    right.alignment = BoxContainer.ALIGNMENT_END
    right.add_child(UITheme.label(info.get("mode", ""), 36, UITheme.WARN))
    mid.add_child(right)

    var bottom := HBoxContainer.new()
    bottom.add_theme_constant_override("separation", 24)
    col.add_child(bottom)
    _bar = ProgressBar.new()
    _bar.min_value = 0.0
    _bar.max_value = 1.0
    _bar.step = 0.001
    _bar.show_percentage = false
    _bar.custom_minimum_size = Vector2(0, 14)
    _bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    _bar.add_theme_stylebox_override("background", UITheme.box(UITheme.GUNMETAL, UITheme.GUNMETAL, 0, 0))
    _bar.add_theme_stylebox_override("fill", UITheme.box(UITheme.ICE, UITheme.ICE, 0, 0))
    bottom.add_child(_bar)
    _pct = UITheme.label("0%", 26, UITheme.TITANIUM)
    _pct.custom_minimum_size = Vector2(90, 0)
    bottom.add_child(_pct)

    if _target.is_empty() or ResourceLoader.load_threaded_request(_target) != OK:
        _fail("无法加载: %s" % _target)


func _process(delta: float) -> void:
    if _finished or _target.is_empty():
        return
    _elapsed += delta
    var prog: Array = []
    var status := ResourceLoader.load_threaded_get_status(_target, prog)
    match status:
        ResourceLoader.THREAD_LOAD_IN_PROGRESS:
            _set_progress(prog[0] if prog.size() > 0 else 0.0)
        ResourceLoader.THREAD_LOAD_LOADED:
            _set_progress(1.0)
            if _elapsed >= MIN_SHOW_TIME:
                _finished = true
                var packed := ResourceLoader.load_threaded_get(_target) as PackedScene
                SceneRouter.goto("", packed)
        _:
            _fail("资源加载失败: %s" % _target)


func _set_progress(v: float) -> void:
    _bar.value = v
    _pct.text = "%d%%" % int(v * 100.0)


func _fail(msg: String) -> void:
    _finished = true
    show_toast(msg, true)
    var back := make_button("返回大厅", false, Vector2(260, 76))
    back.pressed.connect(SceneRouter.goto.bind("res://ui/lobby/lobby.tscn"))
    safe_root.add_child(back)
