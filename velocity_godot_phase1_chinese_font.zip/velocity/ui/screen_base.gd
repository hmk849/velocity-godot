class_name ScreenBase
extends Control
## 全屏界面基类: 背景 + 安全区容器 + Toast。
## 子类实现 _build(root)，不要重写 _ready()。

var background: ColorRect
var safe_root: MarginContainer
var _toast_box: VBoxContainer


func _ready() -> void:
    theme = Game.ui_theme
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    background = ColorRect.new()
    background.color = UITheme.BG
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(background)

    safe_root = MarginContainer.new()
    safe_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var m := SafeArea.margins(get_viewport())
    safe_root.add_theme_constant_override("margin_left", int(m.x) + 56)
    safe_root.add_theme_constant_override("margin_top", int(m.y) + 40)
    safe_root.add_theme_constant_override("margin_right", int(m.z) + 56)
    safe_root.add_theme_constant_override("margin_bottom", int(m.w) + 40)
    add_child(safe_root)

    _toast_box = VBoxContainer.new()
    _toast_box.alignment = BoxContainer.ALIGNMENT_END
    _toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _toast_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _toast_box.offset_bottom = -90
    add_child(_toast_box)

    _build(safe_root)


## 子类重写
func _build(_root: MarginContainer) -> void:
    pass


func show_toast(text: String, is_error := false) -> void:
    while _toast_box.get_child_count() >= 3:
        _toast_box.get_child(0).queue_free()
        _toast_box.remove_child(_toast_box.get_child(0))
    var l := UITheme.label(text, 26, UITheme.WARN if is_error else UITheme.ICE)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.add_theme_stylebox_override("normal", UITheme.box(Color(0.05, 0.06, 0.07, 0.94), UITheme.BORDER, 1, 14))
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _toast_box.add_child(l)
    var tw := l.create_tween()
    tw.tween_interval(2.4)
    tw.tween_property(l, "modulate:a", 0.0, 0.4)
    tw.tween_callback(l.queue_free)


func make_button(text: String, primary := false, min_size := Vector2(0, 76)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    if primary:
        UITheme.style_primary(b)
    return b
