# PROJECT VELOCITY — Godot 版技术方案与第一阶段工程

> 版本 0.1.0-phase1 · 引擎 Godot 4.3+ (Mobile 渲染器) · 语言 GDScript
>
> **状态声明**: 本工程的代码在编写环境中**没有**在 Godot 里实际运行或编译过（环境没有 Godot）。
> 请先按「运行」一节在本机验证，把报错贴回来，我会逐项修。

---

## 1. 从 Unreal 方案到 Godot 的差异（先说清楚）

原指令按 UE5 + C++ 写。换成 Godot 后有几处现实变化：

| 原方案 (UE5) | Godot 方案 | 影响 |
|---|---|---|
| UE5 + C++ / Blueprint | Godot 4 + GDScript（热点路径以后可换 GDExtension / C#） | 开发更快，画面上限和大型项目工具链弱于 UE |
| 内置网络复制 / GAS | `MultiplayerAPI` + ENet，专用服务器用 headless 导出 | 服务器权威、客户端预测、延迟补偿、命中回溯**全部要自己写** |
| Nanite / Lumen | 无；用 Mobile 渲染器 + 烘焙光照 + LOD | 对手游反而更现实 |
| MetaSounds / 空间音频 | `AudioStreamPlayer3D` + 总线混响 | 3D 定位够用，复杂战场混音要自己做 |
| 平台签名 | 一样需要 | iOS 必须 Mac + Xcode + Apple 开发者账号 |

**范围提醒**: 12 名干员、40+ 把枪（含各自模型/动画/音效）、8 张地图、完整联网 —— 这些里**美术、动画、音频资产和后端服务不是写代码能生成的**，需要美术/音频团队或授权素材。代码侧我会逐阶段交付，资产依赖在第 7 节列出。

---

## 2. 目录结构

```
velocity/
├─ project.godot              工程配置（Mobile 渲染器、横屏、Autoload）
├─ ARCHITECTURE.md
├─ core/                      【Core / GameFramework】
│   ├─ game.gd                Autoload Game: 版本、平台、主题、跨场景传参
│   ├─ event_bus.gd           Autoload EventBus: 全局信号
│   ├─ settings.gd            Autoload Settings: 设置读写与应用
│   ├─ scene_router.gd        Autoload SceneRouter: 切场景 + 黑场过渡
│   ├─ input_setup.gd         运行时注册输入动作
│   └─ safe_area.gd           刘海/手势条安全区
├─ account/
│   └─ auth_service.gd        Autoload AuthService: 认证接口（现仅游客可用）
├─ ui/                        【UI】
│   ├─ ui_theme.gd            设计系统: 色板、按钮样式、字体
│   ├─ screen_base.gd         全屏界面基类（安全区、Toast）
│   ├─ boot/  login/  loading/  lobby/  settings/
│   └─ hud/                   hud.gd, touch_controls.gd
├─ gameplay/                  【Character / Movement / Weapon】
│   ├─ player/player.gd       第一人称角色 + 运动状态机
│   ├─ weapon/                weapon.gd（运行时）, weapon_data.gd（数据资源）
│   ├─ targets/               hit_zone.gd, target_dummy.gd
│   └─ maps/test_range.*      临时训练场
├─ data/weapons/*.tres        每把枪一个数据文件
├─ tests/ttk_check.gd         无头 TTK 校验
└─ assets/fonts/              放 NotoSansSC-Regular.otf（见 §6）
```

**规划中的模块**（对应原 UE 模块清单，尚未创建）: `gameplay/abilities`（技能）、`gameplay/modes`（模式规则）、`net/`（联网）、`audio/`、`anticheat/`、`server/`（专用服务器入口）。

---

## 3. 模块依赖关系

```
                ┌────────────── ui/* ──────────────┐
                │                                   │
                ▼                                   ▼
      core (Game / Settings / SceneRouter)     account (AuthService)
                ▲                                   
                │                                   
      gameplay/player ──▶ gameplay/weapon ──▶ data/weapons/*.tres
                │                │
                └──▶  EventBus ◀─┘     ◀── ui/hud 订阅
```

规则：
1. `gameplay` **不得**引用 `ui`；只通过 `EventBus` 发信号，HUD 订阅。
2. `ui` 可以用 `core` 与 `account`，不直接改 gameplay 状态。
3. 所有数值（枪械、移动）走 `@export` 或 `.tres`，不写死在逻辑里。
4. 联网阶段会在 `gameplay` 与 `net` 之间加「输入命令 / 状态快照」接口，gameplay 逻辑须保持可被服务器无头运行（所以现在就不让它依赖 UI 和相机之外的渲染节点）。

---

## 4. 启动流程

```
boot（品牌开场，可点击跳过）
  → login（游客登录可用；Apple/Google/邮箱返回"需要后端"错误态）
  → lobby（占位 3D 假人、导航、设置面板）
  → loading（ResourceLoader 线程加载，真实进度条）
  → test_range（移动 / 射击 / 触屏 HUD）
```

---

## 5. 移动端性能预算（**设计目标，需真机 profile 校准**）

| 项目 | 低端 30FPS | 中端 60FPS | 高端 90FPS |
|---|---|---|---|
| 帧时间 | 33.3 ms | 16.6 ms | 11.1 ms |
| 3D 渲染分辨率 | 0.67× | 0.85× | 1.0× |
| Draw call / 帧 | ≤ 150 | ≤ 250 | ≤ 350 |
| 三角面 / 帧 | ≤ 150k | ≤ 300k | ≤ 500k |
| 实时光源 | 1 平行光 | 1 平行光 + 2 点光 | 1 平行光 + 4 点光 |
| 阴影 | 仅平行光，距离 30m | 距离 50m | 距离 70m |
| 粒子 | ≤ 300 | ≤ 600 | ≤ 1000 |
| 运行内存 | ≤ 1.2 GB | ≤ 1.8 GB | ≤ 2.5 GB |
| 纹理 | ASTC，角色/武器 ≤ 1024² | 同左 | 同左，关键武器 2048² |
| 单帧 CPU：逻辑 / 物理 | ≤ 4 / 2 ms | 同左 | 同左 |

单体面数预算：第三人称角色 ≤ 12k 三角面，第一人称武器 ≤ 15k，场上 12 人 ≤ 150k。
当前已落实：Mobile 渲染器、关闭 MSAA、可调渲染分辨率、正交阴影、无天空盒、材质共享。
Godot 注意点：Mobile 渲染器需要 Vulkan 设备；老旧设备要另出 Compatibility 渲染器包。

---

## 6. 运行与测试

**运行**
1. 安装 Godot 4.3 或更新版本（标准版即可）。
2. 用编辑器打开 `project.godot`，**等它导入完成**（会生成 `class_name` 缓存，必须有）。
3. F5 运行。桌面操作：WASD 移动、鼠标视角、Shift 冲刺、空格跳、C/Ctrl 滑铲、左键开火、R 换弹、Q 换枪、Esc 释放鼠标。
4. 手机上自动启用触屏：左半屏浮动摇杆（推满自动冲刺）、右半屏转视角、右下 FIRE / JUMP / SLIDE / R / SWAP。

**中文显示**: Godot 默认字体不含中文。若界面出现方块，下载 Noto Sans SC（OFL 授权）把 `NotoSansSC-Regular.otf` 放到 `assets/fonts/`，主题会自动使用。

**TTK 无头测试**
```
godot --headless -s tests/ttk_check.gd
```
当前预期：步枪胸部 TTK 225 ms（目标 180–300），SMG 240 ms。

**手感验证清单**: 冲刺→滑铲→滑铲跳→空中转向→落地，速度不应突变；滑铲坡道（左侧）、台阶（右侧）、4 排靶子（正前方）。

---

## 7. 外部依赖（我无法生成，需要你提供或采购）

| 类别 | 内容 |
|---|---|
| 美术 | 12 干员模型+绑定+动画、40+ 枪械模型与第一人称动画、8 张地图的美术资产、LOGO、图标、加载界面概念图 |
| 音频 | 全部枪声/脚步/环境/UI/配乐（原创或授权）；开场低频电子音 |
| 后端 | 认证（Apple/Google/邮箱）、匹配、房间、排行榜；建议自建 Nakama 或用 PlayFab/Firebase；专用游戏服务器托管 |
| 平台 | iOS：Mac + Xcode + Apple Developer 账号 + 签名证书；Android：JDK 17 + Android SDK + keystore；导出模板 |
| 字体 | 中文 CJK 字体 |
| 反作弊 | 基础校验可自写；对抗外挂的成熟方案需第三方 |

---

## 8. 已实现 / 桩 / 未实现（不夸大）

**已实现（逻辑真实）**: 启动流程；游客登录（本地 ID）；线程加载与真实进度；设置（灵敏度/FOV/渲染分辨率/帧率/触控透明度/FPS 显示/自动冲刺）并持久化；第一人称移动（走、冲刺、跳、二段跳、滑铲、滑铲跳、空中动量）；数据驱动武器（2 把）+ hitscan + 距离衰减 + 爆头倍率 + 后坐力 + 散布 + 换弹 + 弹匣；命中标记；训练靶；触屏双摇杆 HUD。

**桩 / 占位**: LOGO（文字）、大厅 3D 角色（胶囊假人）、枪模（方块）、地图（生成的方块）、服务器状态（固定显示离线）。

**未实现**: 蹬墙跑/墙跳/翻越/攀爬/钩爪/滑索、ADS 与瞄准镜、子弹飞行与穿透、配件、干员与技能、其余 6 把以上枪、地图 2–8、所有游戏模式规则、联网/匹配/反作弊、音频、HUD 编辑器、陀螺仪/辅助瞄准/手柄、第三人称动画、Apple/Google/邮箱登录、IPA/APK/AAB 导出配置。

---

## 9. 路线图（与原 9 阶段对应）

| 阶段 | 内容 | 状态 |
|---|---|---|
| 1 | 架构、启动、登录、加载、大厅 | ✅ 本次交付（含 2/3 阶段的最小种子） |
| 2 | 完整移动：蹬墙跑、墙跳、翻越、钩爪、第三人称动画 | 种子已有 |
| 3 | 弹道、ADS/瞄准镜、更多枪、改装数据结构 | 种子已有 |
| 4 | 首张正式地图 + 6V6 团队死斗规则 | — |
| 5 | 联网：服务器权威、预测校正、插值、延迟补偿、匹配、重连 | — |
| 6 | 技能系统、改装界面、训练场、完整设置、HUD 编辑器 | — |
| 7 | 扩展内容 | — |
| 8 | 视觉/音频打磨、性能优化 | — |
| 9 | iOS/Android 打包与发布 | — |
